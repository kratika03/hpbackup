def age_calculator(dobstr):
    return 2022-int(dobstr.split('/')[-1])